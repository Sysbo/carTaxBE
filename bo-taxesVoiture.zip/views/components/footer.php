
<script src="js/calculator.js"></script>
<!-- Option 1: Bootstrap Bundle with Popper -->
<script src="assets/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>