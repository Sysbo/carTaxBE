<!doctype html>
<html lang="fr">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Favicon -->
  <link rel="apple-touch-icon" sizes="180x180" href="assets/favicon/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/favicon/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="assets/favicon/favicon-16x16.png">
  <link rel="manifest" href="assets/favicon/site.webmanifest">
  <link rel="mask-icon" href="assets/favicon/safari-pinned-tab.svg" color="#5bbad5">
  <link rel="shortcut icon" href="assets/favicon/favicon.ico">
  <meta name="msapplication-TileColor" content="#da532c">
  <meta name="msapplication-config" content="assets/favicon/browserconfig.xml">
  <meta name="theme-color" content="#ffffff">

  <!-- Bootstrap CSS -->
  <link href="css/cartax.css" rel="stylesheet">
  <link href="assets/fontawesome-free-6.0.0-web/css/all.min.css" rel="stylesheet">
  <link href="assets/bootstrap-datepicker-1.9.0-dist/css/bootstrap-datepicker3.standalone.min.css" rel="stylesheet">

  <title>Calculateur de taxes sur les véhicules - Belgique</title>
</head>

<body>
  <script src="assets/jquery/jquery-3.6.0.min.js"></script>
  <script src="assets/bootstrap-datepicker-1.9.0-dist/js/bootstrap-datepicker.min.js"></script>
  <script src="assets/bootstrap-datepicker-1.9.0-dist/locales/bootstrap-datepicker.fr.min.js"></script>